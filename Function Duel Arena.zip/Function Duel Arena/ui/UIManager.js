import FunctionParser from '../game/FunctionParser.js';

export default class UIManager {
    constructor(scene) {
        this.scene = scene;

        // DOM Elements
        this.turnIndicator = document.getElementById('turn-indicator');
        this.input = document.getElementById('function-input');
        this.validationMsg = document.getElementById('validation-msg');
        this.previewBtn = document.getElementById('preview-btn');
        this.undoBtn = document.getElementById('undo-btn');
        this.fireBtn = document.getElementById('fire-btn');

        this.p1Hp = document.getElementById('p1-hp');
        this.p2Hp = document.getElementById('p2-hp');

        this.mouseCoords = document.getElementById('mouse-coords');
        this.playerInfo = document.getElementById('player-info');
        this.coordTableBody = document.getElementById('coord-table-body');

        this.dirLeft = document.getElementById('dir-left');
        this.dirRight = document.getElementById('dir-right');
        this.currentDir = 1; // 1 for R, -1 for L

        this.setupListeners();
    }

    setupListeners() {
        this.input.addEventListener('input', () => {
            const result = FunctionParser.parse(this.input.value);
            this.updateValidation(result);
            if (result.success) this.updateCoordTable(result.node);
        });

        this.dirLeft.addEventListener('click', () => this.setDirection(-1));
        this.dirRight.addEventListener('click', () => this.setDirection(1));

        // Track global mouse coords in grid units
        this.scene.input.on('pointermove', (pointer) => {
            const gridX = this.scene.mapManager.toGridX(pointer.x);
            const gridY = this.scene.mapManager.toGridY(pointer.y);
            this.mouseCoords.textContent = `Mouse: (${gridX.toFixed(1)}, ${gridY.toFixed(1)})`;
        });

        this.previewBtn.addEventListener('click', () => {
            const charges = this.scene.previewCharges[this.scene.turn];
            if (charges <= 0) return;

            const result = FunctionParser.parse(this.input.value);
            if (result.success) {
                this.scene.previewCharges[this.scene.turn]--;
                this.scene.events.emit('preview-function', result.node, this.currentDir);
                this.updateCoordTable(result.node);
                this.updatePreviewButtonText();
            }
        });

        this.fireBtn.addEventListener('click', () => {
            const result = FunctionParser.parse(this.input.value);
            if (result.success) {
                this.scene.events.emit('fire-function', result, this.currentDir);
                this.disableInput();
                this.clearTable();
            }
        });

        this.undoBtn.addEventListener('click', () => {
            this.input.value = '';
            this.updateValidation({ success: false, error: '' });
            this.scene.events.emit('clear-preview');
            this.clearTable();
        });
    }

    setDirection(dir) {
        this.currentDir = dir;
        this.dirLeft.classList.toggle('active', dir === -1);
        this.dirRight.classList.toggle('active', dir === 1);

        // Refresh preview if it's visible
        const result = FunctionParser.parse(this.input.value);
        if (result.success) {
            this.scene.events.emit('preview-function', result.node, this.currentDir);
            this.updateCoordTable(result.node);
        }
    }

    updateCoordTable(mathNode) {
        this.clearTable();

        // High-resolution points: 0.5 step, wider range [-8, +8]
        const playerGridX = this.scene.mapManager.toGridX(this.scene.currentPlayer.x);
        const startX = Math.floor(playerGridX - 8);
        const endX = Math.ceil(playerGridX + 8);

        for (let gx = startX; gx <= endX; gx += 0.5) {
            const gy = FunctionParser.evaluate(mathNode, gx);
            const row = document.createElement('tr');

            // Highlighting
            const isInteger = Number.isInteger(gx);
            const isExactPlayer = Math.abs(gx - playerGridX) < 0.1;

            if (isExactPlayer) {
                row.style.color = '#58a6ff';
                row.style.fontWeight = 'bold';
                row.style.backgroundColor = 'rgba(88, 166, 255, 0.1)';
            } else if (isInteger) {
                row.style.color = '#e6edf3';
            } else {
                row.style.color = '#8b949e';
                row.style.fontSize = '0.9em';
            }

            row.innerHTML = `<td>${gx.toFixed(1)}</td><td>${gy.toFixed(3)}</td>`;
            this.coordTableBody.appendChild(row);
        }
    }

    clearTable() {
        this.coordTableBody.innerHTML = '';
    }

    updateValidation(result) {
        if (!this.input.value) {
            this.validationMsg.textContent = '';
            this.fireBtn.disabled = true;
            this.previewBtn.disabled = true;
            return;
        }

        if (result.success) {
            this.validationMsg.textContent = `Valid! DMG Multiplier: ${result.complexityMultiplier}x`;
            this.validationMsg.className = 'success';
            this.fireBtn.disabled = false;

            const charges = this.scene.previewCharges[this.scene.turn];
            this.previewBtn.disabled = charges <= 0;
        } else {
            this.validationMsg.textContent = result.error;
            this.validationMsg.className = 'error';
            this.fireBtn.disabled = true;
            this.previewBtn.disabled = true;
        }
    }

    updateHP(p1, p2) {
        this.p1Hp.style.width = `${p1}%`;
        this.p2Hp.style.width = `${p2}%`;
    }

    updateTurn(turn) {
        this.turnIndicator.textContent = `PLAYER ${turn}'S TURN`;
        this.turnIndicator.style.color = turn === 1 ? '#58a6ff' : '#da3633';
        this.enableInput();
        this.updatePreviewButtonText();

        // Calculate dynamic direction (toward opponent)
        const opponent = turn === 1 ? this.scene.player2 : this.scene.player1;
        const dir = (opponent.x > this.scene.currentPlayer.x) ? 1 : -1;
        this.setDirection(dir);

        // Update player position info
        const playerX = this.scene.mapManager.toGridX(this.scene.currentPlayer.x);
        const playerY = this.scene.mapManager.toGridY(this.scene.currentPlayer.y);
        this.playerInfo.textContent = `Your Pos: (${playerX.toFixed(1)}, ${playerY.toFixed(1)})`;
    }

    updatePreviewButtonText() {
        const charges = this.scene.previewCharges[this.scene.turn];
        this.previewBtn.textContent = `Preview (${charges})`;
        this.previewBtn.disabled = charges <= 0;

        if (charges <= 0) {
            this.previewBtn.title = "No preview charges remaining";
        } else {
            this.previewBtn.title = "";
        }
    }

    disableInput() {
        this.input.disabled = true;
        this.fireBtn.disabled = true;
        this.previewBtn.disabled = true;
        this.undoBtn.disabled = true;
    }

    enableInput() {
        this.input.disabled = false;
        this.undoBtn.disabled = false;
        this.input.value = '';
        this.updateValidation({ success: false, error: '' });
    }

    showResult(winner) {
        this.turnIndicator.textContent = `PLAYER ${winner} WINS!`;
        this.disableInput();
    }
}
