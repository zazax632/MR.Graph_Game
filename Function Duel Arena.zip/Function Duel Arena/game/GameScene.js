import MapManager from './MapManager.js';
import Player from './Player.js';
import Projectile from './Projectile.js';
import UIManager from '../ui/UIManager.js';
import GraphPreview from '../ui/GraphPreview.js';
import DamageSystem from './DamageSystem.js';

export default class GameScene extends Phaser.Scene {
    constructor() {
        super('GameScene');
    }

    create() {
        this.mapManager = new MapManager(this);
        this.mapManager.drawGrid();
        this.obstacle = this.mapManager.createObstacle();

        // Create "Ground" at Y = -2 (below players)
        const groundY = this.mapManager.toScreenY(-2);
        this.ground = this.add.rectangle(
            this.sys.game.config.width / 2,
            groundY,
            this.sys.game.config.width,
            40, // Deeper ground for better visuals
            0x21262d, // Darker color
            1
        );
        this.physics.add.existing(this.ground, true);

        // Visible ground line
        this.add.line(0, 0, 0, groundY, this.sys.game.config.width, groundY, 0x3fb950, 0.8).setOrigin(0);

        // Simple impact texture
        const graphics = this.make.graphics({ x: 0, y: 0, add: false });
        graphics.fillStyle(0xffffff);
        graphics.fillRect(0, 0, 4, 4);
        graphics.generateTexture('impact', 4, 4);

        // Players
        const p1X = this.mapManager.toScreenX(-15);
        const p1Y = this.mapManager.toScreenY(0);
        this.player1 = new Player(this, p1X, p1Y, 1, 0x58a6ff);

        const p2X = this.mapManager.toScreenX(15);
        const p2Y = this.mapManager.toScreenY(0);
        this.player2 = new Player(this, p2X, p2Y, 2, 0xda3633);

        this.currentPlayer = this.player1;
        this.turn = 1;

        // State
        this.isFiring = false;
        this.projectile = null;
        this.previewCharges = { 1: 3, 2: 3 };

        // UI
        this.ui = new UIManager(this);
        this.preview = new GraphPreview(this, this.mapManager);
        this.ui.updateTurn(1); // Set initial UI state

        this.setupEvents();
    }

    setupEvents() {
        this.events.on('preview-function', (mathNode, direction) => {
            this.preview.show(mathNode, this.currentPlayer.x, this.currentPlayer.y, direction, this.currentPlayer.id === 1 ? 0x58a6ff : 0xda3633);
        });

        this.events.on('clear-preview', () => {
            this.preview.clear();
        });

        this.events.on('fire-function', (parseResult, direction) => {
            this.fire(parseResult, direction);
        });
    }

    fire(parseResult, direction) {
        if (this.isFiring) return;
        this.isFiring = true;
        this.preview.clear();

        // P1 fires Right (1), P2 fires Left (-1)
        // const direction = this.currentPlayer.id === 1 ? 1 : -1; // This is now passed as a parameter
        const color = this.currentPlayer.id === 1 ? 0x58a6ff : 0xda3633;

        this.projectile = new Projectile(
            this,
            this.currentPlayer.x,
            this.currentPlayer.y,
            parseResult.node,
            direction,
            color,
            this.mapManager
        );

        this.projectile.complexityMultiplier = parseResult.complexityMultiplier;

        // Manual collision handling is now done inside Projectile.update() 
        // using the targets and obstacle properties for higher precision.
    }

    handleGroundHit(projectile) {
        if (!projectile.active || projectile.isFinished) return;
        this.createImpact(projectile.x, projectile.y, 0x00ff00);
        projectile.finish();
        this.endTurn();
    }

    handleHit(player, projectile) {
        // Stop the projectile from hitting anything else or continuing
        if (!projectile.active || projectile.isFinished) return;

        // Real Graphwar logic: 100 damage = Instant death
        const damage = 100;
        player.takeDamage(damage);

        this.ui.updateHP(this.player1.hp, this.player2.hp);

        // Impact effect
        this.createImpact(projectile.x, projectile.y, projectile.fillColor);

        projectile.finish();
        this.checkGameOver();
        this.endTurn();
    }

    handleObstacleHit(projectile, obstacle) {
        if (!projectile.active || projectile.isFinished) return;

        // Impact effect
        this.createImpact(projectile.x, projectile.y, 0x30363d);

        projectile.finish();
        this.endTurn();
    }

    createImpact(x, y, color) {
        const particles = this.add.particles(x, y, 'impact', {
            speed: { min: -100, max: 100 },
            angle: { min: 0, max: 360 },
            scale: { start: 0.1, end: 0 },
            blendMode: 'ADD',
            lifespan: 500,
            quantity: 10,
            emitting: false,
            tint: color
        });
        particles.explode();
        this.time.delayedCall(500, () => particles.destroy());
    }

    endTurn() {
        if (!this.isFiring) return;
        this.isFiring = false;
        this.projectile = null;

        if (this.player1.hp <= 0 || this.player2.hp <= 0) return;

        this.time.delayedCall(1000, () => {
            this.turn = this.turn === 1 ? 2 : 1;
            this.currentPlayer = this.turn === 1 ? this.player1 : this.player2;
            this.ui.updateTurn(this.turn);
        });
    }

    checkGameOver() {
        let winner = 0;
        if (this.player1.hp <= 0) winner = 2;
        else if (this.player2.hp <= 0) winner = 1;

        if (winner !== 0) {
            this.ui.showResult(winner);
            // Respawn after delay
            this.time.delayedCall(3000, () => this.resetGame());
        }
    }

    resetGame() {
        // Full Random spawning anywhere in the arena [-19, 19]
        let p1gx = -19 + Math.random() * 38;
        let p2gx = -19 + Math.random() * 38;

        // Ensure minimum distance of 8 grid units
        while (Math.abs(p1gx - p2gx) < 8) {
            p2gx = -19 + Math.random() * 38;
        }

        const p1X = this.mapManager.toScreenX(p1gx);
        const p1Y = this.mapManager.toScreenY(0);
        this.player1.setPosition(p1X, p1Y);
        this.player1.hp = 100;

        const p2X = this.mapManager.toScreenX(p2gx);
        const p2Y = this.mapManager.toScreenY(0);
        this.player2.setPosition(p2X, p2Y);
        this.player2.hp = 100;

        // Reset state
        this.turn = 1;
        this.currentPlayer = this.player1;
        this.isFiring = false;
        this.projectile = null;
        this.previewCharges = { 1: 3, 2: 3 };

        // Update UI
        this.ui.updateHP(100, 100);
        this.ui.updateTurn(1);
    }

    update() {
        // If we have a projectile, update it
        if (this.projectile) {
            if (this.projectile.active) {
                this.projectile.update();
            } else {
                // If it exists but is no longer active (e.g. finished/destroyed)
                // and we haven't handled the turn end yet
                if (this.isFiring) {
                    // Start the turn end process
                    this.endTurn();
                }
                // Null it to stop update logic
                this.projectile = null;
            }
        }
    }
}
